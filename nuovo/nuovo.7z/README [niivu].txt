nuovo for Windows 11 22H2 (niivu) -  May 14 2023
(https://www.deviantart.com/niivu)
For updates check here (https://www.deviantart.com/niivu/art/nuovo-22H2-961180405)

Hello and thanks for your interest in trying it out.

CREDITS - https://www.deviantart.com/coroners (caption buttons)
WALLPAPER CREDITS - https://unsplash.com/@philipsfuture (edited by niivu)

Icons in preview can be found here.
https://www.deviantart.com/niivu/art/Fluent-Keys-Icon-Theme-860328216

Explorer font in preview is Hasklig.(included and required for foobar2000 skin)

### RESULTS WILL VARY DEPENDING ON DPI SETTINGS.###  
### SOME BUGS ARE KNOWN AND CANNOT BE CONTROLED AT THIS TIME.###
You should create a system restore point prior to instalation.

Please read the instructions carefully before posting issues.  For those unfamiliar with installing Windows themes I suggest first you read the guide.
Again, results will very depending on things such as dpi settings.
https://www.deviantart.com/niivu/art/Guide-To-Installing-Windows-10-Themes-708835586

Required for best results use the following.  There's many settings and options available to achieve your desired look.

## StartAllBack - (https://www.startallback.com/)

## MicaForEveryone - (https://github.com/MicaForEveryone/MicaForEveryone/releases)

--

## Chrome
1. Place the Chrome folder and contents into a directory of your choosing.
2. Launch Chrome and go to `chrome://extensions`.
3. Check the "Developer mode" checkbox at the top. 
4. Click the "Load unpacked extension..." button and choose the desired theme directory (`Chrome/BLACK` or `Chrome/WHITE`).

(To reset or remove the theme, visit `chrome://settings` and click "Reset to Default" in the "Appearance" section.)

***Chrome Fix for the titlebar and caption buttons***

Right click the taskbar or desktop shortcut of Chrome > Right Click the browser name > Properties and after "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" in the "Target" field, add --disable-windows10-custom-titlebar at the end and click Apply. Should look exactly like this: 

"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --disable-windows10-custom-titlebar

Start your browser using the shortcut and the titlebar and caption buttons will now match the Windows theme.

--

## foobar 2000 + ColumnsUI

You'll need to install the included font (Hasklig) 
(https://www.foobar2000.org/)  +  (https://yuo.be/columns-ui)

1.  Copy the skin folder and components into your foobar2000 folder.
2.  Make sure your runnung the latest foobar2000 with ColumnsUI as the interface.
3.  Go to preferences -> ColumnsUI -> Main -> use Import Button to import the .fcl located in the Skin folder.
4.  For best view -> disable toolbars (click top left edge button) and status bar.

## 7tsp extras

Remove the file extension ".remove" from the file before using.
You'll need to use 7TSP GUI 2019 Edition (https://www.deviantart.com/devillnside/art/7TSP-GUI-2019-Edition-804769422)

1.  Open up 7TSP & click Add a Custom Pack & select the icon pack you want to install.  
2.  Click on Start Patching.
3.  By default 7TSP will create a restore point & install.
4.  Once installation is done reboot & you're done.

These are included to color the parts not able to with the theme alone. Mainly control panel and winver colors.
Only for use on Windows 11 22H2.

--

Enjoy!
-niivu
