solarized for Windows 11 - OCT 14 2023
by
niivu

https://www.deviantart.com/niivu

Solarized is a sixteen color palette (eight monotones, eight accent colors) designed for use with terminal and gui applications. Designed by Ethan Schoonover.
https://ethanschoonover.com/solarized/

--

NA stands for No addressbar.
RESULTS WILL VARY DEPENDING ON DPI SETTINGS.  SOME BUGS ARE KNOWN AND CANNOT BE CONTROLED AT THIS TIME.
Please read the instructions carefully before posting issues.  For those unfamiliar with installing Windows themes I suggest first you read the guide here.  Again, results will very depending on dpi settings.

Warning:  If you are new to this or unsure it's always best to create a System Restore Point before continuing.

Installing Windows 11 themes Guide - (https://www.deviantart.com/niivu/art/Installing-Windows-Themes-UPDATED-708835586)

(Font in new preview is DaddyTimeMono + the nerd font variation for the terminal)

## Taskbar Icons

For setting up shortcut icons in taskbar use the following guide also by @dpcdpc11
HOW TO CHANGE THE APP ICONS IN THE WINDOWS TASKBAR - https://www.deviantart.com/dpcdpc11/journal/HOW-TO-CHANGE-THE-APP-ICONS-IN-THE-WINDOWS-TASKBAR-891158884

## StartAllBack

Place the files in your Program Files/StartAllBack folder directories and apply through the program.
Includes Orbs and StartMenu/Taskbar.

## foobar2000

(https://www.foobar2000.org/)  +  (https://yuo.be/columns-ui)
foobar2000 v1.6.16		Latest version

1.  Copy the skin folder and components into your foobar2000 folder.
2.  Make sure your running foobar2000 with ColumnsUI as the interface.
3.  Go to preferences -> ColumnsUI -> Main -> use Import Button to import the .fcl located in the Skin folder.
4.  For best view -> disable toolbars (click top left edge button) and status bar.

*PC and User Icons can be changed in the the themes icons folder.

CREDITS ///

If you've downloaded this from a site rather than DeviantArt consider it stolen.  Please do not redistribute.  For the latest on updates check here...
https://www.deviantart.com/niivu
Thanks, and enjoy!
-niivu