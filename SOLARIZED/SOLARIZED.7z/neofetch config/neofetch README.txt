You can edit the user name in the config.conf file.

Place the config.conf in your neofetch directory.

https://github.com/chick2d/neofetch-themes
# Made by IdliDev (https://github.com/Idlidev)(modded by niivu - https://www.deviantart.com/niivu)

*Font download - https://www.nerdfonts.com/font-downloads 

DaddyTimeMono Nerd Font


-niivu