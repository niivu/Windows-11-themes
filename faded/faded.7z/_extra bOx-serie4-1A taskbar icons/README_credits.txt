bOx-serie4-1A - Icon extras WIP

Some extra icons I'm working on to match.
Credits to Grayhouse for the original icon theme.

https://www.deviantart.com/grayhouse/art/bOx-serie4-1A-921774432

-niivu