..:: foobar2000 Skins by niivu ::..
Requirements:

:: foobar2000

:: ColumnsUI (Latest pre-release version)

Setup:

:: copy the components into your foobar2000 folder.

:: have the above fonts installed before continuing.

:: Make sure your runnung the latest foobar2000 with ColumnsUI as the interface.

:: go to preferences -> ColumnsUI -> Main -> use Import Button to import the .fcl located in the Skin folder.

Best view:

:: disable toolbars (click top left edge button) and status bar.