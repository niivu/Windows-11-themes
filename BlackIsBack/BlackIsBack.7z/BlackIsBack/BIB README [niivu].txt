BlackIsBack for Windows 11 22H2 (niivu) 1.3 -  April 18 2023

(https://www.deviantart.com/niivu)

Wallpapers in preview can be found on UNSPLASH here.
https://unsplash.com/@boliviainteligente

Icons in preview can here.
https://www.deviantart.com/niivu/art/Fluent-Keys-Icon-Theme-860328216

Explorer font in preview is Hasklig.

RESULTS WILL VARY DEPENDING ON DPI SETTINGS.  SOME BUGS ARE KNOWN AND CANNOT BE CONTROLED AT THIS TIME.
You should create a system restore point prior to instalation.

Please read the instructions carefully before posting issues.  For those unfamiliar with installing Windows themes I suggest first you read the guide.
Again, results will very depending on things such as dpi settings.
https://www.deviantart.com/niivu/art/Guide-To-Installing-Windows-10-Themes-708835586

Required for best results.

## StartAllBack - (https://www.startallback.com/)

## MicaForEveryone - (https://github.com/MicaForEveryone/MicaForEveryone/releases)

--

## foobar 2000 + ColumnsUI

You'll need to install the included font (FF DIN Round Pro) 
(https://www.foobar2000.org/)  +  (https://yuo.be/columns-ui)

1.  Copy the skin folder and components into your foobar2000 folder.
2.  Make sure your runnung the latest foobar2000 with ColumnsUI as the interface.
3.  Go to preferences -> ColumnsUI -> Main -> use Import Button to import the .fcl located in the Skin folder.
4.  For best view -> disable toolbars (click top left edge button) and status bar.

--

## 7tsp extras

Remove the file extension ".remove" from the file before using.
You'll need to use 7TSP GUI 2019 Edition (https://www.deviantart.com/devillnside/art/7TSP-GUI-2019-Edition-804769422)

1.  Open up 7TSP & click Add a Custom Pack & select the icon pack you want to install.  
2.  Click on Start Patching.
3.  By default 7TSP will create a restore point & install.
4.  Once installation is done reboot & you're done.

These are included to color the parts not able to with the theme alone. Mainly control panel and winver colors.
Only for use on Windows 11 22H2.

--

Enjoy!
-niivu